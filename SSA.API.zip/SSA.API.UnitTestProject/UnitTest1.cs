﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;

namespace SSA.API.UnitTestProject
{
    [TestClass]
    public class UnitTest1
    {
        public static readonly Queue<int> queue = new Queue<int>();
        [TestMethod]
        public void TestMethod1()
        {
            for (int i = 0; i < 10; i++)
            {
              
            }

            

            
        }
    }
}
